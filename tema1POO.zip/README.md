1.   In clasa main se joaca mai multe meciuri.
2.   In clasa match sunt mai multe metode. In Match se initializeaza
mai multe campuri, precum deckul, tabla, eroii jucatorilor, 
numarul de runde jucate. Metoda shuffleDecks este pentru a amesteca
deckurile. Metoda round creste numarul de runde jucate si
seteaza mana jucatorilor. endMatch seteaza victoriile si numarul
de meciuri jucate. playGame este metoda principala care verifica
inputul primit si in functie de acesta apeleaza diferite comenzi.
3.   In clasa player cele mai importante lucruri sunt metodele getDeck
si setHero.
4.   Clasa de enumerare Command este pentru o nota de originalitate.
Spre exemplu, in loc sa scriu node.putPOJO("output", copy), eu pot sa scriu
node.putPOJO(Command.output.name(), copy). Nu are o functionalitate in acest cod, este
doar pentru a incerca lucruri noi.
5. Toate comenzile se afla in pachetul commands. Le-am pus pe 2 
categorii: de gameplay (cand cartile se ataca) si de debug (pentru a afla starea jocului).
Mai sunt 2 comenzi de statistici ale jucatorilor, dar sunt direct in Match.
6. Toate cartile se afla in pachetul cards. Pentru a da o nota de originalitate,
am facut clasa abstracta Cards. Nu ne dorim sa avem obiecte de tip cards, doar de
minioni/eroi. Desi nu ne dorim nici obiecte de tip erou, eu nu am reusit sa fac clasa
abstracta, deoarece abstractizarea claselor a fost gandita destul de tarziu. De asemenea,
avem interfata Ability, care este implementata de cartile ce au abilitati. Minionii speciali
sunt in pachetul specialMinions. Exista si obiecte Minion, dar si obiecte de tip Minioni
speciali, asadar abstractizarea clasei Minion nu ar fi fost posibila. Eroii (specifici)
sunt in pachetul heroes. Deoarece nu ne dorim obiecte de tip erou (pentru un design mai oop),
am creat si aceste clase: EmpressThorina, GeneralKocioraw, LordRoyce, KingMudface.
7. Clasa Constants a fost facuta pentru a fi mai usor de urmarit codul. Daca voiam sa scriu
10, ar fi trebuit sa scriu 2 + 2 de 5 ori(altfel, checkstyle error). In schimb,
acum pot sa scriu TEN. De ce nu am lasat asa? Pentru ca am vrut sa fie mai usor de urmarit
codul. Acum toate numerele sunt scrise in litere mari, usor de urmarit.
8. In main se joaca mai multe meciuri.