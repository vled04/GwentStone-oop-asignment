package org.poo.game.cards;

public class Constants {
    public final static int ZERO = 0;
    public final static int ONE = 1;
    public final static int TWO = 2;
    public final static int THREE = 3;
    public final static int FOUR = 4;
    public final static int FIVE = 5;
    public final static int TEN = 10;
    public final static int THIRTY = 30;
    }

